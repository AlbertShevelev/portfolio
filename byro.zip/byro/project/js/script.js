
$(document).ready(function(){
    $('.sidenav').sidenav();
});
$.ajax({
    url: 'http://127.0.0.1:8000/project',
    success: function (arg) {
        for(var i=0;i<arg.length;i++){
            var divRow=document.createElement("div");
            document.body.appendChild(divRow);
            divRow.classList.add("row");
            var divCol=document.createElement("div");
            divRow.appendChild(divCol);
            divCol.classList.add("col",["s12"],"m6");
            var divCard=document.createElement("div");
            divCol.appendChild(divCard);
            divCard.classList.add("card",["blue-grey"],"darken-1");
            var divCardContent=document.createElement("div");
            divCard.appendChild(divCardContent);
            divCardContent.classList.add("card-content",["white-text"]);
            var span=document.createElement("span");
            divCardContent.appendChild(span);
            span.classList.add("card-title");
            span.innerHTML=arg[i].title;
            var p=document.createElement("p");
            divCardContent.appendChild(p);
            p.innerHTML=arg[i].description;
            var divCardAction=document.createElement("div");
            divCard.appendChild(divCardAction);
            divCardAction.classList.add("card-action");
            var a1=document.createElement("a");
            divCardAction.appendChild(a1);
            a1.innerHTML=arg[i].contact;
        }
    }
});
//var input=document.querySelector("input");
//var val=input.value;
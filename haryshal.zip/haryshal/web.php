<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
use Illuminate\Http\Request;
use Illuminate\Database\Eloquent\Collection;
Route::get('/project', function (Request $req) {
    header("Access-Control-Allow-Origin: *");
    $all=App\Items::all();
    return $all;
});
Route::get('/projecth', function (Request $req) {
    header("Access-Control-Allow-Origin: *");
    App\Items::create([
        "title"=>$req->title,
        "description"=>$req->description,
        "contact"=>$req->contact,
    ]);
});
Route::get('/useradd', function (Request $req) {
    header("Access-Control-Allow-Origin: *");
    App\User::create([
        "login"=>$req->login,
        "password"=>$req->password,
        "mail"=>$req->email,
    ]);
});
Route::get('/check', function (Request $req) {
    header("Access-Control-Allow-Origin: *");
    $get=App\User::where('login',$req->login)->where('password',$req->password)->get();
    return $get;
});
Route::get('/checkrole', function (Request $req) {
    header("Access-Control-Allow-Origin: *");
    $clientfind=App\Client::where("user_id",$req->uid)->get();
    $volunteerfind=App\Volunteer::where("user_id",$req->uid)->get();
    $coll = new Collection();
    $find = $coll->merge($clientfind)->merge($volunteerfind);
    return $find;
});
Route::get('/client', function (Request $req) {
    header("Access-Control-Allow-Origin: *");
    App\Client::create([
        "fullnameparent"=>$req->fullnameparent,
        "fullnamechild"=>$req->fullnamechild,
        "diagnosis"=>$req->diagnosis,
        "phonenumber"=>$req->phonenumber,
    ]);
});
Route::get('/volunteer', function (Request $req) {
    header("Access-Control-Allow-Origin: *");
    App\Volunteer::create([
        "fullname"=>$req->fullname,
        "age"=>$req->age,
        "seriapasporta"=>$req->seriapasporta,
        "nomerpasporta"=>$req->nomerpasporta,
        "phone"=>$req->phone,
    ]);
});
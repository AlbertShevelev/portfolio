﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class bullet1 : MonoBehaviour {
	void Start () {
		
	}
	void Update () {
		
	}
	void OnCollisionEnter(Collision arg){
		if (arg.gameObject.tag == "bullet_delete") {
			Destroy (gameObject);
		}
	}
}
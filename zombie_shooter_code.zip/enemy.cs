﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.SceneManagement;

public class enemy : MonoBehaviour {
	NavMeshAgent nav;
	Animator anim;

	public Transform target;

	Transform tra;
	Rigidbody ins;
	float hp=10f;
	void Start () {
		nav = GetComponent<NavMeshAgent> ();
		anim = GetComponent<Animator> ();
		tra = GetComponent<Transform> ();

	}
	void Update () {
		nav.SetDestination (target.position);
	}
	void OnCollisionEnter(Collision arg){
		if (arg.gameObject.tag == "bullet") {
			anim.SetBool ("isfalling", true);
			nav.enabled = false;
		}
		if (arg.gameObject.tag == "MainCamera") {
			anim.SetBool ("attacking", true);
			hp = hp - 1f;
			if (hp < 1) {
				SceneManager.LoadScene("scene2");
			}
		}
	}

}
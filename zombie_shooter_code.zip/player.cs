﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class player : MonoBehaviour {
	bool zoom = false;
	Rigidbody rb;
	Transform tr;
	float f2;
	float h;
	float v;
	float f;
	float msx;
	Rigidbody ins;
	Camera cam1;
	public Camera cam2;
	public Rigidbody mainObject;
	public Transform dulo;
	void Start () {
		rb = GetComponent<Rigidbody> ();
		tr = GetComponent<Transform> ();
		cam1 = GetComponent<Camera> ();
	}
	void Update () {
		v = Input.GetAxis ("Vertical");
		h = Input.GetAxis ("Horizontal");
		f = Input.GetAxis ("Fire1");
		f2 = Input.GetAxis ("Fire2");
		msx = Input.GetAxis ("Mouse X");
		Vector3 rotation = new Vector3(0,msx,0);
		rb.AddForce (tr.forward * v * 100f);
		tr.Rotate (rotation * 7f);
		if (f > 0) {
			ins = Instantiate (mainObject, dulo.position,dulo.rotation);
			ins.AddForce (tr.forward * 2500f);
		}
		if (f2 > 0) {
			zoom = true;
		} else {
			zoom = false;
		}
		if (zoom == true) {
			cam1.enabled = false;
			cam2.enabled = true;
		} else {
			cam1.enabled = true;
			cam2.enabled = false;
		}
	}
}
﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class spawner : MonoBehaviour {
	public GameObject spawning;
	public Transform place_for_spawn;
	// Use this for initialization
	void Start () {
		spawning.GetComponent<Transform> ();
		spawning.GetComponent<Rigidbody> ();
		InvokeRepeating("respawn",4f,10f);
	}
	
	// Update is called once per frame
	void Update () {
		
	}
	void respawn(){
		Instantiate (spawning, place_for_spawn.position, place_for_spawn.rotation);
	}
}
